<p>Greetings</p>
<p>You have been added to VESIT in campus placement procedure</p>
<p>Your Username: {{ $username }}</p>
<p>Your Password: {{ $password }}</p>