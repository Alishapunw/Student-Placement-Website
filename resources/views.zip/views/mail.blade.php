


<h1>Email OTP: {{ $name }}</h1>
<p>Please verify your email to continue.</p>