<h2>Company Name: {{$c_name}}</h2>
<h3>Minimun Average CGPA: {{$minPointer}} </h3>
<h3>Intake: {{$intake}}</h3>
<h3>Vacancies: {{$vacancies}}</h3>