@extends('layout.app')
@section('content')
<!DOCTYPE html>
<html>
<head>
	<title>Vesit Placement</title>
</head>
<body>
{{-- <p>Hello</p> --}}
</body>
</html>
@endsection