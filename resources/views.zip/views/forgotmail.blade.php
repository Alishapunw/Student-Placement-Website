


<h1>Your Reset Password is: {{ $name }}</h1>
<p>Please do login</p>