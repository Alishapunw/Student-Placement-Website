@extends('layout.app')
@section('content')
{{-- <link rel="stylesheet" href="{{ asset('css/style.css') }}" type="text/css">
<script src="{{  asset('js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation.js') }}"></script> --}}
 


<body>
  <br>
  <br>
  <br>
  <br>
<div class="container-fluid">
   <div class="row content">
      <div class="col-sm-1">
         
      </div>
   <div class="col-md-5">
      <br>
      <div class="row">
      <h1 class="entry-title">Contact Us</h1>
      </div>
      <br>
      <div class="container">
        <p><strong>Address: </strong><br>
         V.E.S. Institute of Technology,<br>
         Hashu Advani Memorial Complex (HAMC),<br>
         Collector’s Colony, R C Marg,<br>
         Chembur, Mumbai -74</p>
         <p><strong>Landmarks:</strong>&nbsp;Jhama Chowk (Chembur Camp), Near Municipal School (Collector's Colony)</p>        
         <p><strong>Training and Placement Officer: </strong>Mr. Nagananda A.<br>
         <strong> Tel :</strong>&nbsp;+91-22-61532510 / +91-9136132532 <br>
         <strong>Phone:</strong> +91-22-61532532 Ext: 586 / +91-22-61532586 (D)<br>
         <strong>Email Address:</strong> tpo@ves.ac.in</p>
         
         <p><strong>Deputy Training and Placement Officer: </strong>Mr. Dashrath Mane<br>
         <strong> Tel :</strong>&nbsp;022-61532586 <br>
         <strong>Phone:</strong>+91-9892249823<br>
         <strong>Email Address:</strong>dashrath.mane@ves.ac.in</p>
         
      </div>       
   </div>
   <div class="col-md-6" style="padding-right:0px !important;">
      <div class="mu-venue-map">
          <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3995.6767507457416!2d72.88685776538789!3d19.045411557706785!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x3be7c8add9569a29%3A0xb7ad04bf9a389df7!2sVivekanand+Education+Society&#39;s+Institute+Of+Technology+Chembur+Mumbai!5e0!3m2!1sen!2sin!4v1549381669803" width="95%" height="450" frameborder="0" style="border:0" allowfullscreen=""></iframe>  
      </div>
   </div>
</div>
</div><br>

</body>
@endsection
