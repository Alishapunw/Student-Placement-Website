@extends('layout.app')
@section('content')

{{-- <link rel="stylesheet" href="{{ asset('css/style.css') }}" type="text/css">
<script src="{{  asset('js/jquery.min.js') }}"></script>
<script type="text/javascript" src="{{ URL::asset('js/validation.js') }}"></script> --}}
<head>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>


        <link href="{{asset('css/styles2.css')}}" rel="stylesheet">
        <link href="{{asset('css/style.css')}}" rel="stylesheet">
        <style>
      
      h2 {margin:2rem 0;}

        * {
  box-sizing: border-box;
}

body {
  margin: 0px;
  font-family: Arial;
}

.header {
  text-align: center;
  padding: 32px;
}

.row {
  display: -ms-flexbox; /* IE10 */
  display: flex;
  -ms-flex-wrap: wrap; /* IE10 */
  flex-wrap: wrap;
  padding: 20px;
  margin-left:20px;
  margin-right:20px;
}

/* Create four equal columns that sits next to each other */
.column {
  -ms-flex: 33.33%; /* IE10 */
  flex: 33.33%;
  max-width: 33.33%;
  padding: 0 4px;
}



/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}

.column img {
  margin-top: 20px;
  vertical-align: middle;
  width: 100%;
}

.text-wrapper {
    margin-top: 70px;
    margin-bottom:0px;
  width: 400px;
  height: 90px;
  position: absolute;
  display: flex;
  flex-direction: column;
  justify-content: center;
  text-align: center;
  color: #fff;
  opacity: 0;
}

.text-wrapper:hover {
  transition: all 0.8s ease;
  background: rgba(0, 0, 0, 0.6);
  opacity: 1;
}

.name {
    margin-left: 50px;
    margin-right:30%;
  font-size: 1.8em;
}


/* Responsive layout - makes a two column-layout instead of four columns */
@media screen and (max-width: 800px) {
  .column {
    -ms-flex: 50%;
    flex: 50%;
    max-width: 50%;
  }
}

/* Responsive layout - makes the two columns stack on top of each other instead of next to each other */
@media screen and (max-width: 600px) {
  .column {
    -ms-flex: 100%;
    flex: 100%;
    max-width: 100%;
  }
}



</style>
        </head>

<body>

<!-- Header -->
<div class="header">
<br><br><br>
<p><strong><h2 style="text-align: center; color:#204184;">Our Current Events</h2></strong></p>
</div>

<br>

<div class="container">

  
  <div class="card-deck">
    
    <div class="card" style=" background:rgb(248,248,255)">
      <img class="card-img-top img-fluid" src="{{asset('images/events/accp2.jpg')}}" alt="Card image cap" style=" width:100%;height:90%">
      
      <div class="card-body ">
       <center> <h4 class="card-title"><strong>ACCENTURE PLACEMENT DRIVE</strong></h4> </center>
       <center> <p class="card-text">
       <!--<a href="#" class="btn btn-info" role="button">More Images</a>-->
       
       </p> 
        </center>
      </div>
    </div>
   
  
    <div class="card" style=" background:rgb(248,248,255)">
      <img class="card-img-top img-fluid" src="{{asset('images/events/er2.jpg')}}" alt="Card image cap" style=" width:100%;height:90%">
      
      <div class="card-body ">
       <center> <h4 class="card-title"><strong>ElasticRun DREAM DRIVE </strong></h4> </center>
       <center> <p class="card-text">
       <!--<a href="#" class="btn btn-info" role="button">More Images</a>-->
       </p> 
        </center>
      </div>
    </div>
   

    <div class="card" style=" background:rgb(248,248,255)">
      <img class="card-img-top img-fluid" src="{{asset('images/events/accp1.jpg')}}" alt="Card image cap" style=" width:100%;height:90%">
      
      <div class="card-body ">
       <center> <h4 class="card-title"><strong>ACCENTURE PLACEMENT DRIVE</strong></h4> </center>
       <center> <p class="card-text">
       <!--<a href="#" class="btn btn-info" role="button">More Images</a>-->
       </p> 
        </center>
      </div>
    </div>
   
   </div>

   <div class="header">
<br>
<p><strong><h2 style="text-align: center; color:#204184;">Our Recent Events</h2></strong></p>
</div>

</div>

<!-- Photo Grid -->
<div class="row"> 
  


  <div class="column">
  <span class="text-wrapper"><span class="name">ACCENTURE PLACEMENT DRIVE</span></span>
    <img src="{{asset('images/events/accp1.jpg')}}"style="width:100% ">
    <span class="text-wrapper">
    <span class="name">BURNS AND MCDOWELL DRIVE </span></span>
    <img src="{{asset('images/events/bnm1.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">NETWORK MARVELL DRIVE </span></span>
    <img src="{{asset('images/events/nm1.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">MCA ALUMNI INTERACTION</span></span>
    <img src="{{asset('images/events/mca1.jpg')}}"style="width:100%">
    <span class="text-wrapper">
    <span class="name">ACUCERT LAB LLP DRIVE</span></span>
     <img src="{{asset('images/events/llp1.jpg')}}" style="width:100%">
    </div>
  

  <div class="column">
  <span class="text-wrapper">
    <span class="name">ACCENTURE PLACEMENT DRIVE</span></span>
    <img src="{{asset('images/events/accp2.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">BURNS AND MCDOWELL DRIVE </span></span>
    <img src="{{asset('images/events/bnm2.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">NETWORK MARVELL DRIVE </span></span>
    <img src="{{asset('images/events/nm2.jpg')}}"style="width:100%">
    <span class="text-wrapper">
    <span class="name">MCA ALUMNI INTERACTION</span></span>
    <img src="{{asset('images/events/mca2.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">ACUCERT LAB LLP DRIVE</span></span>
    <img src="{{asset('images/events/llp2.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">ACUCERT LAB LLP DRIVE</span></span>
    <img src="{{asset('images/events/llp3.jpg')}}" style="width:100%">
  
  </div>
  <div class="column">
  <span class="text-wrapper">
    <span class="name">ACCENTURE PLACEMENT DRIVE</span></span>
    <img src="{{asset('images/events/accp3.jpg')}}"style="width:100%">
    <span class="text-wrapper">
    <span class="name">BURNS AND MCDOWELL DRIVE </span></span>
    <img src="{{asset('images/events/bnm3.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">NETWORK MARVELL DRIVE </span></span>
    <img src="{{asset('images/events/nm3.jpg')}}" style="width:100%">
    <span class="text-wrapper">
    <span class="name">MCA ALUMINI INTERACTION</span></span>
    <img src="{{asset('images/events/mca3.jpg')}}"style="width:100%">
    
   
  </div>  

 
</div>


</body>




@endsection
